# Noyo / LiftMatch Pro — Project Structure

## Recommended GitHub structure

```
.
├── index.html
├── js/
│   ├── app.js
│   └── firebase-bridge.js
├── assets/
│   └── css/
│       └── styles.css
└── backups/
    └── index.original.backup.html
```

## What each file does

- `index.html` — main entry page and all HTML markup
- `js/firebase-bridge.js` — Firebase config, auth, Firestore bridge helpers
- `js/app.js` — main application logic and UI behaviour
- `assets/css/styles.css` — extracted stylesheet from the original inline CSS
- `backups/index.original.backup.html` — original backup copy before tidy-up

## Important load order

Keep these references in `index.html` in this order:

1. Firebase CDN scripts
2. `js/firebase-bridge.js`
3. CSS file link in `<head>`
4. Chart.js CDN script
5. `js/app.js` near the end of `<body>`

## GitHub setup

Upload the full folder contents to the root of your repository.
Do not upload only `index.html`, because it depends on the CSS and JS folders.

## Optional next cleanup

- move Firebase secrets/config to environment-based injection for production
- split `app.js` into smaller modules like `auth.js`, `ui.js`, `quotes.js`, `admin.js`
- move repeated inline `style="..."` attributes into CSS classes
